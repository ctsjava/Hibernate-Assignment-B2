package com.entity;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.CascadeType;
import javax.persistence.Column;

@Entity
@Table(name="language")
public class Language {
	
	@Id
	@Column(name="language_id")
	private byte languageId;
	
	@Column(name="name")
	private String name;
	
	@Column(name="last_update")
	private Timestamp lastUpdate;
	
	
	@OneToMany
	@JoinColumn(name="language_id")
	List<Film> film=new ArrayList<>();
		
	public List<Film> getFilm() {
		return film;
	}


	public void setFilm(List<Film> film) {
		this.film = film;
	}


	public byte getLanguageId() {
		return languageId;
	}
	

	public void setLanguageId(byte languageId) {
		this.languageId = languageId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Timestamp getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	
}
