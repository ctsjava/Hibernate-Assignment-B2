package com.report;

import org.hibernate.query.Query;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.configure.HibernateUtil;
import com.entity.Actor;
import com.entity.Category;
import com.entity.Film;

public class ListMovieActor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session ses = sf.openSession();

		/*
		CriteriaBuilder cb = ses.getCriteriaBuilder();

		CriteriaQuery<Actor> q = cb.createQuery(Actor.class);
		Root<Actor> root = q.from(Actor.class);
		q.select(root).where(cb.equal(root.get("firstName"), "PENELOPE"));
		Query<Actor> query = ses.createQuery(q);
		List<Actor> actorRows = query.getResultList();
		for (Actor actor : actorRows) 
		{
			for (Film film:actor.getFilm())
			{
				System.out.print(film.getFilmId()+" ");
				System.out.print(film.getTitle()+" ");
				System.out.print(film.getDescription()+" ");
				System.out.print(actor.getFirstName()+" ");
				System.out.println();
			}
			System.out.println();
		}
		
		*/
		
		
		String q1 = "from Actor c where c.firstName='PENELOPE'";
		TypedQuery<Actor> qry = ses.createQuery(q1,Actor.class);

		List<Actor> actors= qry.getResultList();

		for (Actor actor : actors) {
			List<Film> films=actor.getFilm();
			
			for (Film film:films)
			{
				System.out.print(film.getFilmId()+"\t");
				System.out.print(film.getTitle()+"\t");
				System.out.print(film.getDescription()+"\t");
				System.out.print(actor.getFirstName());
				System.out.println();
			}
			System.out.println();
		
	}
		
	}

}
