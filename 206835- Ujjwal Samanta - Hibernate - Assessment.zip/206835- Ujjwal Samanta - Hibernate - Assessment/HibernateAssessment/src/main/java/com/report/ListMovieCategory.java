package com.report;

import org.hibernate.query.Query;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.configure.HibernateUtil;
import com.entity.Category;
import com.entity.Film;
import javax.persistence.TypedQuery;

public class ListMovieCategory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session ses = sf.openSession();
	
		/*
		CriteriaBuilder cb = ses.getCriteriaBuilder();

		CriteriaQuery<Category> q = cb.createQuery(Category.class);
		Root<Category> root = q.from(Category.class);
		q.select(root).where(cb.equal(root.get("name"), "Action"));
		Query<Category> query = ses.createQuery(q);
		List<Category> categoryRows = query.getResultList();
		for (Category category : categoryRows) 
		{
			
			for (Film film:category.getFilm())
			{
				System.out.print(film.getFilmId()+" ");
				System.out.print(film.getTitle()+" ");
				System.out.print(film.getDescription()+" ");
				System.out.print(category.getName()+" ");
				System.out.println();
			}
			System.out.println();
		}
		
		*/
		
		String q1 = "from Category c where c.name='action'";
		TypedQuery<Category> qry = ses.createQuery(q1,Category.class);

		List<Category> catgories= qry.getResultList();

		for (Category category : catgories) {
			List<Film> films=category.getFilm();
			
			for (Film film:films)
			{
				System.out.print(film.getFilmId()+" ");
				System.out.print(film.getTitle()+" ");
				System.out.print(film.getDescription()+" ");
				System.out.print(category.getName()+" ");
				System.out.println();
			}
			System.out.println();
		
	}

	}
}
