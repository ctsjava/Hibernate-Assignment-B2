package com.report;

import org.hibernate.query.Query;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.configure.HibernateUtil;
import com.entity.Film;

public class ListMovieRelease {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session ses = sf.openSession();

		/*
		CriteriaBuilder cb = ses.getCriteriaBuilder();
		CriteriaQuery<Film> q = cb.createQuery(Film.class);
		Root<Film> root = q.from(Film.class);
		q.select(root).where(cb.equal(root.get("releaseYear"), 2006));
		Query<Film> query = ses.createQuery(q);
		List<Film> films = query.getResultList();
		for (Film film : films) 
		{
			System.out.print(film.getFilmId()+"\t");
			System.out.print(film.getTitle()+"\t");
			System.out.print(film.getDescription()+"\t");
			System.out.println(film.getReleaseYear());
			
		}
		
		*/
		
		
		String q1 = "from Film f where f.releaseYear=2006";

		TypedQuery<Film> qry = ses.createQuery(q1,Film.class);

		List<Film> films = qry.getResultList();

		for (Film film : films) {
			System.out.print(film.getFilmId()+"\t");
			System.out.print(film.getTitle()+"\t");
			System.out.print(film.getDescription()+"\t");
			System.out.println(film.getReleaseYear());
			
		}
		
		
	}

}
