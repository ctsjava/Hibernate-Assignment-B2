package com.report;

import org.hibernate.query.Query;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.configure.HibernateUtil;
import com.entity.Actor;
import com.entity.Film;
import com.entity.Language;

public class ListMovieLanguage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session ses = sf.openSession();

		/*
		CriteriaBuilder cb = ses.getCriteriaBuilder();

		CriteriaQuery<Language> q = cb.createQuery(Language.class);
		Root<Language> root = q.from(Language.class);
		q.select(root).where(cb.equal(root.get("name"), "English"));
		Query<Language> query = ses.createQuery(q);
		List<Language> languageRows = query.getResultList();
		for (Language language : languageRows) 
		{
			for (Film film:language.getFilm())
			{
				System.out.print(film.getFilmId()+" ");
				System.out.print(film.getTitle()+" ");
				System.out.print(film.getDescription()+" ");
				System.out.print(language.getName()+" ");
				System.out.println();
			}
			System.out.println();
		}
		
		*/
				
		
				
		String q1 = "from Language c where c.name='English'";
		TypedQuery<Language> qry = ses.createQuery(q1,Language.class);

		List<Language> languages= qry.getResultList();

		for (Language language : languages) {
			List<Film> films=language.getFilm();
			
			for (Film film:films)
			{
				System.out.print(film.getFilmId()+" ");
				System.out.print(film.getTitle()+" ");
				System.out.print(film.getDescription()+" ");
				System.out.print(language.getName()+" ");
				System.out.println();
			}
			System.out.println();
		
	}
		
	}

}
