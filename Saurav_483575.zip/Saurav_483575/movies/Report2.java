package com.saurav.movies;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class Report2 {

	public static void main(String[] args) 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session ses = sf.openSession();
		
		CriteriaBuilder cb = ses.getCriteriaBuilder();

		CriteriaQuery<Actor> q = cb.createQuery(Actor.class);
		Root<Actor> root = q.from(Actor.class);
		q.select(root).where(cb.equal(root.get("first_name"), "PENELOPE"));
		Query<Actor> query = ses.createQuery(q);
		List<Actor> rows = query.getResultList();
		for (Actor actor : rows) {
			for(Film film:actor.getFilms())
			{
				System.out.print(film.getFilm_id()+"\t");
				System.out.print(film.getTitle()+"\t");
				System.out.print(film.getDescription()+"\t");
				System.out.println(actor.getFirst_name());
			}
			
		}
	}

}
