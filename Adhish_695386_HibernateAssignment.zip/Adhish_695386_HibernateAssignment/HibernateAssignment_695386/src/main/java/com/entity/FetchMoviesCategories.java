package com.entity;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.config.HibernateUtil;

public class FetchMoviesCategories {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session ses = sf.openSession();

		Query<Category> q2 = ses.createNamedQuery("category_action", Category.class);

		List<Category> films = q2.list();

		
		for (Category movies: films) {
			
		for (Movies movie: movies.getMovies()) {
			System.out.println("Film ID: " + movie.getFilm_id());
			System.out.println("Film Name: " + movie.getTitle());
			System.out.println("Film Description: " + movie.getDescription());
			
			System.out.println("--------------------------------------");
		}
		}
			

	}
	
}
